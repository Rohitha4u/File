package com.xworkz.app.thread;

import java.util.Arrays;

public class ThreadImpl extends Thread{
	private void Run() {
		System.out.println("invoked running");

	}
	public void start() {
		System.out.println("invoked start");
	}
	
	
}
