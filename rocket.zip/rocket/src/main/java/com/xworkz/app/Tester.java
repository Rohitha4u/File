package com.xworkz.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Tester {

	public static void main(String[] args) {
		try {
			String xmlConfigPath="spring.xml";
			ApplicationContext container=new ClassPathXmlApplicationContext(xmlConfigPath);
			Rocket refOfRocket =container.getBean(Rocket.class);
			refOfRocket.Launch();
			
		}catch(Exception e) {
			e.printStackTrace();
		}

	}

}
