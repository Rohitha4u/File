package com.xworkz.app;

public class Satellite {

	private int price;
	private String name;
	
	public Satellite() {
		System.out.println("Created \t"+this.getClass().getSimpleName());
	}
	
	public void setPrice(int price) {
		this.price=price;
		System.out.println("Created \t"+price);
	}
	public void setName(String name) {
		this.name=name;
		System.out.println("Created \t"+name);
	}
	public void Launch() {
		System.out.println("invoked launch");
	}

	@Override
	public String toString() {
		return "Satellite [price=" + price + ", name=" + name + "]";
	}
	
}
