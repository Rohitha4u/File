package com.xworkz.app;

public class Fuel {

	private int liter;
	
	  public Fuel(int liter) {
		this.liter=liter;
		System.out.println("Created \t"+liter);
	}
	  
	  public void fire() {
		System.out.println("invoked fire");
	  }

	@Override
	public String toString() {
		return "Fuel [liter=" + liter + "]";
	}
	  
}
