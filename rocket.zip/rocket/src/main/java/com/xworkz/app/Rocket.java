package com.xworkz.app;

public class Rocket {

	private Fuel fuel;
	private Satellite satellite;
	private String countryName;
	
	public Rocket(Fuel fuel) {
		this.fuel=fuel;
		System.out.println("Created \t"+fuel);
	}
	public void setSatellite(Satellite satellite) {
		this.satellite=satellite;
		System.out.println("Created \t"+satellite);
	}
	public void setCountryName(String countryName) {
		this.countryName=countryName;
		System.out.println("Created \t"+countryName);
	}
	public void Start() {
		this.fuel.fire();
	}
	public void Launch() {
		this.satellite.Launch();
	}
	@Override
	public String toString() {
		return "Rocket [fuel=" + fuel + ", satellite=" + satellite + ", countryName=" + countryName + "]";
	}

	
}
