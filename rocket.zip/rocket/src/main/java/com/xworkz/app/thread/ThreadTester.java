package com.xworkz.app.thread;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.xworkz.app.Rocket;

public class ThreadTester {

	public static void main(String[] args) {
	try {
		 String xmlConfigPath="spring.xml";
		ApplicationContext container=new ClassPathXmlApplicationContext(xmlConfigPath);
		
		Labour refOfLabour=container.getBean(Labour.class);
		refOfLabour.work();
	}catch(Exception e) {
		e.printStackTrace();
	}
	}
}
